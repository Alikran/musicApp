package course.examples.Services.KeyClient;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import course.examples.Services.KeyCommon.KeyGenerator;

public class KeyServiceUser extends Activity {

	protected static final String TAG = "KeyServiceUser";
	protected static final int PERMISSION_REQUEST = 0;
	private KeyGenerator myKeyGeneratorService;
	private boolean mIsBound = false;

	Button bindBtn;
	Button unBindBtn;
	Button startBtn;
	TextView myStatus;

	private List<String> songNames;
	private List<String> songArtists;
	private List<String> songUrls;
	private List<Integer> songPics;

	ArrayList<String>  mySongNameList;
	ArrayList<Integer> myImagesList;
	ArrayList<String> myArtistList;
	ArrayList<String> myUrlList;

	private MediaPlayer myPlayer = new MediaPlayer();


	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.main);

		bindBtn = findViewById(R.id.bind_btn);
		unBindBtn = findViewById(R.id.unbind_btn);
		startBtn = findViewById(R.id.musicLibrary_btn);
		myStatus = findViewById(R.id.myStatus);


		startBtn.setEnabled(false);
		unBindBtn.setEnabled(false);
		bindBtn.setEnabled(true);

		bindBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				checkBindingAndBind();
				bindBtn.setEnabled(false);
				unBindBtn.setEnabled(true);
				startBtn.setEnabled(true);
				myStatus.setText("Current Status: binded");
			}
		});

		unBindBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mIsBound = false;
				unbindService(mConnection);
				unBindBtn.setEnabled(false);
				startBtn.setEnabled(false);
				bindBtn.setEnabled(true);
				myStatus.setText("Current Status: unbinded");
			}
		});

		startBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				setContentView(R.layout.recycler_view);
				RecyclerView myRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
				//populate list for adapters
				populateList();

				RVClickListener rvListener = (view,position)->
				{
					TextView name = (TextView)view.findViewById(R.id.textSongTitle);
					Toast.makeText(getBaseContext(),name.getText(),Toast.LENGTH_SHORT).show();
					String audioUrl = myUrlList.get(position);
					myPlayer.stop();
					myPlayer.seekTo(0);
					myPlayer.setAudioAttributes(
							new AudioAttributes.Builder()
									.setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
									.setUsage(AudioAttributes.USAGE_MEDIA)
									.build()

					);

					try{
						myPlayer.setDataSource(audioUrl);
						myPlayer.prepareAsync();
						myPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
							@Override
							public void onPrepared(MediaPlayer mp) {
								mp.start();
							}
						});

					} catch (Exception e) {
						e.printStackTrace();
					}

					Log.i("messages", audioUrl);

				};

				myAdapter adapter = new myAdapter(mySongNameList,myImagesList, myArtistList,rvListener);

				myRecyclerView.setAdapter(adapter);
				myRecyclerView.setLayoutManager(new GridLayoutManager(getBaseContext(), 1));
			}
		});

	}

	// Bind to KeyGenerator Service
	@Override
	protected void onStart() {
		super.onStart();

		if (checkSelfPermission("course.examples.Services.KeyService.GEN_ID")
			!= PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this,
					new String[]{"course.examples.Services.KeyService.GEN_ID"},
					PERMISSION_REQUEST);
		}
		else {
			checkBindingAndBind();
		}
	}

	protected void checkBindingAndBind() {
		if (!mIsBound) {

			boolean b = false;
			Intent i = new Intent(KeyGenerator.class.getName());
			// UB:  Stoooopid Android API-21 no longer supports implicit intents
			// to bind to a service #@%^!@..&**!@
			// Must make intent explicit or lower target API level to 20.
			ResolveInfo info = getPackageManager().resolveService(i, 0);
			i.setComponent(new ComponentName(info.serviceInfo.packageName, info.serviceInfo.name));
			b = bindService(i, this.mConnection, Context.BIND_AUTO_CREATE);
			if (b) {
				Log.i(TAG, "Ugo says bindService() succeeded!");
			} else {
				Log.i(TAG, "Ugo says bindService() failed!");
			}
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		switch (requestCode) {
			case PERMISSION_REQUEST: {
				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					// Permission granted, go ahead and display map
					checkBindingAndBind();
				}
				else {
					Toast.makeText(this, "BUMMER: No Permission :-(", Toast.LENGTH_LONG).show() ;
				}
			}
			default: {
				// do nothing
			}
		}
	}
	// Unbind from KeyGenerator Service
	@Override
	protected void onStop() {
		super.onStop();
		super.onPause();
		if (mIsBound) {
			unbindService(this.mConnection);
		}
	}

	private final ServiceConnection mConnection = new ServiceConnection() {

		public void onServiceConnected(ComponentName className, IBinder iservice) {
			myKeyGeneratorService = KeyGenerator.Stub.asInterface(iservice);
			mIsBound = true;
			getData();
		}

		public void onServiceDisconnected(ComponentName className) {
			myKeyGeneratorService = null;
			mIsBound = false;

		}
	};

	@Override
	public void onResume() {
		super.onResume();
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	public void populateList(){
		songPics = Arrays.asList(R.drawable.harampic, R.drawable.thehouseisburningpic, R.drawable.ghettolennyslovesongspic, R.drawable.atlienspic,
				R.drawable.letithappenpic, R.drawable.discoverypic, R.drawable.isolationpic, R.drawable.suenosdedalipic);

		//populate list for adapters
		mySongNameList = new ArrayList<>();
		mySongNameList.addAll(songNames);

		myArtistList = new ArrayList<>();
		myArtistList.addAll(songArtists);

		myImagesList = new ArrayList<>();
		myImagesList.addAll(songPics);

		myUrlList = new ArrayList<>();
		myUrlList.addAll(songUrls);
	}

	public void getData(){
		try {
			myKeyGeneratorService.initSongs();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		try {
			songNames = Arrays.asList(myKeyGeneratorService.getSongTitle(1), myKeyGeneratorService.getSongTitle(2), myKeyGeneratorService.getSongTitle(3), myKeyGeneratorService.getSongTitle(4),
					myKeyGeneratorService.getSongTitle(5), myKeyGeneratorService.getSongTitle(6), myKeyGeneratorService.getSongTitle(7), myKeyGeneratorService.getSongTitle(8));
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		try {
			songArtists = Arrays.asList(myKeyGeneratorService.getArtist(1), myKeyGeneratorService.getArtist(2), myKeyGeneratorService.getArtist(3), myKeyGeneratorService.getArtist(4),
					myKeyGeneratorService.getArtist(5), myKeyGeneratorService.getArtist(6), myKeyGeneratorService.getArtist(7), myKeyGeneratorService.getArtist(8));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		try {
			songUrls = Arrays.asList(myKeyGeneratorService.getSongUrl(1), myKeyGeneratorService.getSongUrl(2), myKeyGeneratorService.getSongUrl(3), myKeyGeneratorService.getSongUrl(4),
					myKeyGeneratorService.getSongUrl(5), myKeyGeneratorService.getSongUrl(6), myKeyGeneratorService.getSongUrl(7), myKeyGeneratorService.getSongUrl(8));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
}
