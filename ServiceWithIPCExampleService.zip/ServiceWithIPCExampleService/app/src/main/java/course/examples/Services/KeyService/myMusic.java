package course.examples.Services.KeyService;

import android.os.Parcel;
import android.os.Parcelable;

/*
(1) the title of the song,
(2) the name of artist or band who plays the song,
(3) a picture (bitmap) associated with the song, and
(4) a string denoting the URL of a web site containing an audio file for the song.
 */
public class myMusic implements Parcelable{

    private String songTitle;
    private String artist;
    private Integer songPic;
    private String songURL;
    private Integer songNumber;
    private Integer songFile;

    //default constructor
    public myMusic(String myTitle, String myArtist, Integer myPic, String myURL, Integer myNum, Integer myFile){
        this.songTitle = myTitle;
        this.artist = myArtist;
        this.songPic = myPic;
        this.songURL = myURL;
        this.songNumber = myNum;
        this.songFile = myFile;
    }

    protected myMusic(Parcel in) {
        songTitle = in.readString();
        artist = in.readString();
        if (in.readByte() == 0) {
            songPic = null;
        } else {
            songPic = in.readInt();
        }
        songURL = in.readString();
        if (in.readByte() == 0) {
            songNumber = null;
        } else {
            songNumber = in.readInt();
        }
    }

    public static final Creator<myMusic> CREATOR = new Creator<myMusic>() {
        @Override
        public myMusic createFromParcel(Parcel in) {
            return new myMusic(in);
        }

        @Override
        public myMusic[] newArray(int size) {
            return new myMusic[size];
        }
    };

    //getter methods
    public String getSongTitle() {
        return songTitle;
    }
    public String getArtist() {
        return artist;
    }
    public Integer getSongPic() {
        return songPic;
    }
    public String getSongURL() {
        return songURL;
    }
    public Integer getSongNumber() {
        return songNumber;
    }
    public Integer getSongFile() {
        return songFile;
    }

    public String getMySongInfo(){
        return songTitle + ", " + artist + ", " + songPic.toString() + ", " + songURL;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(songTitle);
        dest.writeString(artist);
        if (songPic == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(songPic);
        }
        dest.writeString(songURL);
        if (songNumber == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(songNumber);
        }
    }
}
