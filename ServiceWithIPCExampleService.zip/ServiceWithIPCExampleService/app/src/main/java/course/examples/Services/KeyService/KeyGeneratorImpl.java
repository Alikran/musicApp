package course.examples.Services.KeyService;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import course.examples.Services.KeyCommon.KeyGenerator;

public class KeyGeneratorImpl extends Service {

	// Set of already assigned IDs
	// Note: These keys are not guaranteed to be unique if the Service is killed 
	// and restarted.
	
	private final static Set<UUID> mIDs = new HashSet<UUID>();
	private List<myMusic> mySongs = new ArrayList<>();
	private MediaPlayer mPlayer;

	// Implement the Stub for this Object
	private final KeyGenerator.Stub mBinder = new KeyGenerator.Stub() {

		// Implement the remote method
		public String[] getKey() {
			UUID id;
			// Acquire lock to ensure exclusive access to mIDs 
			// Then examine and modify mIDs
			checkCallingPermission("course.examples.Services.KeyService.GEN_ID") ;
			synchronized (mIDs) {
				do {
					id = UUID.randomUUID();
				} while (mIDs.contains(id));
				mIDs.add(id);
			}
			String[] s;
			s = new String[]{ id.toString()};
			Log.i("Ugo says", "String is: " + s[0]) ;
			return s;
		}

		public String getAllSongs() throws RemoteException {
			String s = "";
			for(int i = 0; i < mySongs.size(); i++){
				s = s.concat(mySongs.get(i).getMySongInfo()+ "\n");
			}
			return s;
		}

		public String getSongInfo(int songNum) throws RemoteException {
			for(int i = 0; i < mySongs.size(); i++){
				if(mySongs.get(i).getSongNumber() == songNum){
					return mySongs.get(i).getMySongInfo();
				}
			}
			return null;
		}

		public String getSongUrl(int songNum) throws RemoteException {
			for(int i = 0; i < mySongs.size(); i++){
				if(mySongs.get(i).getSongNumber() == songNum){
					return mySongs.get(i).getSongURL();
				}
			}
			return null;
		}

		public void playSong(int songNum) throws RemoteException{
			for(int i = 0; i < mySongs.size(); i++){
				if(mySongs.get(i).getSongNumber() == songNum){
					mPlayer = MediaPlayer.create(getBaseContext(),mySongs.get(i).getSongFile());
					mPlayer.start();
				}
			}
			return;
		}

		@Override
		public void initSongs() throws RemoteException {
			mySongs.add(new myMusic("Terrordome","GoldLink",R.drawable.harampic,"https://www.mboxdrive.com/terrordome.mp3",1,R.raw.terrordome));
			mySongs.add(new myMusic("Wat u Sed","Isaiah Rashad",R.drawable.thehouseisburningpic,"https://www.mboxdrive.com/watused.mp3",2,R.raw.watused));
			mySongs.add(new myMusic("All I Want Is A Yacht", "SAINt JHN",R.drawable.ghettolennyslovesongspic,"https://www.mboxdrive.com/alliwantisayacht.mp3",3,R.raw.alliwantisayacht));
			mySongs.add(new myMusic("Jazzy Belle","Outkast",R.drawable.atlienspic,"https://www.mboxdrive.com/jazzybelle.mp3",4,R.raw.jazzybelle));
			mySongs.add(new myMusic("Let It Happen", "Tame Impala",R.drawable.letithappenpic,"https://www.mboxdrive.com/letithappen.mp3",5,R.drawable.letithappenpic));
			mySongs.add(new myMusic("Something About Us", "Daft Punk", R.drawable.discoverypic,"https://www.mboxdrive.com/somethingaboutus.mp3",6,R.raw.somethingaboutus));
			mySongs.add(new myMusic("Dead To Me", "Kali Uchis",R.drawable.isolationpic,"https://www.mboxdrive.com/deadtome.mp3",7,R.raw.deadtome));
			mySongs.add(new myMusic("Traumada", "Paloma Mami",R.drawable.suenosdedalipic,"https://www.mboxdrive.com/traumada.mp3",8,R.raw.traumada));
		}

		public String getSongTitle(int songNum) throws RemoteException {
			for(int i = 0; i < mySongs.size(); i++){
				if(mySongs.get(i).getSongNumber() == songNum){
					return mySongs.get(i).getSongTitle();
				}
			}
			return null;
		}

		public String getArtist(int songNum) throws RemoteException {
			for(int i = 0; i < mySongs.size(); i++){
				if(mySongs.get(i).getSongNumber() == songNum){
					return mySongs.get(i).getArtist();
				}
			}
			return null;
		}
	};

	// Return the Stub defined above
	@Override
	public IBinder onBind(Intent intent) {
		return mBinder;
	}

}
